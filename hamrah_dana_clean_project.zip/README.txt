همراه دانا - پروژه Flutter

ساختار فایل:
- pubspec.yaml
- lib/main.dart
- server/main.py
- server/requirements.txt

نکته:
- کلید API در این ZIP وجود ندارد و نباید در اپ یا GitHub قرار بگیرد.
- برای پاسخ‌گویی واقعی باید OPENAI_API_KEY به صورت Secret در تنظیمات سرویس Render ثبت شود.
- این ZIP شامل پوشه android نیست؛ فایل Workflow در GitHub باید پروژه را استخراج کند و سپس flutter create برای Android اجرا کند.
