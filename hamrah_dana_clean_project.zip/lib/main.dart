import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const HamrahDanaApp());

class HamrahDanaApp extends StatelessWidget {
  const HamrahDanaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'همراه دانا',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101522),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C8CFF),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      home: const ChatPage(),
    );
  }
}

class ChatMessage {
  final String text;
  final bool fromUser;
  ChatMessage(this.text, this.fromUser);
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();

  final messages = <ChatMessage>[
    ChatMessage('سلام! من همراه دانا هستم. چه کمکی از دستم برمیاد؟', false),
  ];

  bool loading = false;

  Future<void> send() async {
    final value = controller.text.trim();
    if (value.isEmpty || loading) return;

    setState(() {
      messages.add(ChatMessage(value, true));
      loading = true;
      controller.clear();
    });

    try {
      final response = await http
          .post(
            Uri.parse('https://hamrah-dana.onrender.com/chat'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'message': value}),
          )
          .timeout(const Duration(seconds: 90));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        setState(() {
          messages.add(
            ChatMessage(data['answer'] ?? 'پاسخی دریافت نشد.', false),
          );
        });
      } else {
        setState(() {
          messages.add(
            ChatMessage(
              'سرور پاسخ موفق نداد (کد ${response.statusCode}). '
              'باید تنظیمات سرور را بررسی کنیم.',
              false,
            ),
          );
        });
      }
    } catch (_) {
      setState(() {
        messages.add(
          ChatMessage(
            'اتصال برقرار نشد. اینترنت و وضعیت سرور را بررسی کن.',
            false,
          ),
        );
      });
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF171F31),
        title: const Row(
          children: [
            CircleAvatar(
              backgroundColor: Color(0xFF6C8CFF),
              child: Icon(Icons.auto_awesome, color: Colors.white),
            ),
            SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'همراه دانا',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  'دستیار هوشمند',
                  style: TextStyle(fontSize: 11, color: Colors.white70),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final item = messages[index];
                return Align(
                  alignment: item.fromUser
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 310),
                    margin: const EdgeInsets.symmetric(vertical: 7),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: item.fromUser
                          ? const Color(0xFF425FC2)
                          : const Color(0xFF202B40),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(
                      item.text,
                      textDirection: TextDirection.rtl,
                      style: const TextStyle(fontSize: 15, height: 1.6),
                    ),
                  ),
                );
              },
            ),
          ),
          if (loading)
            const Padding(
              padding: EdgeInsets.all(8),
              child: Text('همراه دانا در حال پاسخ‌گویی است...'),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      textDirection: TextDirection.rtl,
                      minLines: 1,
                      maxLines: 4,
                      onSubmitted: (_) => send(),
                      decoration: InputDecoration(
                        hintText: 'پیامت رو بنویس...',
                        filled: true,
                        fillColor: const Color(0xFF202B40),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 12,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: loading ? null : send,
                    icon: const Icon(Icons.send_rounded),
                    style: IconButton.styleFrom(
                      backgroundColor: const Color(0xFF6C8CFF),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
